# KiFit Workout Android

KiFit is a starter Android Studio project wrapping a mobile-friendly Indonesian home-workout app in an Android WebView.

## Build APK
1. Install Android Studio on a computer.
2. Open this `KiFitAndroid` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK platform requested by the project (compile SDK 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Android phone and allow installation from that file manager when prompted.

## Included
- Weekly workout plan in Indonesian
- Editable daily workout names, durations, and movements
- 40-second work / 20-second rest timer, three rounds
- Daily movement checkboxes, simple progress and estimated calories
- Local profile name and photo storage
- Indonesian text-to-speech encouragement (device voice availability varies)
- Reminder time preference saved locally

## Current limitations
- This source package is not itself a compiled APK; it needs an Android build environment to compile.
- Reminder time is saved as a preference only; reliable scheduled Android notifications require native notification/alarm implementation and runtime permission handling.
- The Goku-themed guide is represented by a workout/strength motif in this starter build. Add artwork you have rights to use if you want a specific anime character image.
- Progress and profile are stored locally on the device and are not cloud-synced.
